import React, { useState } from "react";
import { Product, formatCurrency } from "@/lib/data";
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { ShoppingCart, ExternalLink } from "lucide-react";
import ProductDetail from "./ProductDetail";

interface ProductSuggestionsProps {
  products: Product[];
  onProductSelect?: (productId: string) => void;
}

const ProductSuggestions: React.FC<ProductSuggestionsProps> = ({ products, onProductSelect }) => {
  const { addToCart } = useCart();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  if (products.length === 0) return null;

  const handleViewProduct = (product: Product) => {
    // Call the onProductSelect callback if provided
    if (onProductSelect) {
      onProductSelect(product.id);
    }
    setSelectedProduct(product);
    setIsDetailOpen(true);
  };

  const handleAddToCart = (product: Product) => {
    addToCart(product, 1);
    // Also count as a product selection
    if (onProductSelect) {
      onProductSelect(product.id);
    }
  };

  return (
    <div>
      <p className="font-medium mb-3">Here are some suggestions for you:</p>
      <div className="grid grid-cols-1 gap-3">
        {products.map(product => (
          <div key={product.id} className="bg-white rounded-lg shadow-sm border p-2 flex">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-16 h-16 object-cover rounded-md"
            />
            <div className="ml-3 flex-1">
              <h4 className="font-medium text-sm line-clamp-1">{product.name}</h4>
              <p className="text-sm text-gray-500 line-clamp-1">{product.description}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="font-bold text-shop-primary">{formatCurrency(product.price)}</span>
                <div className="flex space-x-1">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="h-7 px-2 text-xs"
                    onClick={() => handleViewProduct(product)}
                  >
                    <ExternalLink size={12} className="mr-1" />
                    View
                  </Button>
                  <Button 
                    size="sm" 
                    className="h-7 px-2 text-xs bg-shop-primary hover:bg-shop-primary/90"
                    onClick={() => handleAddToCart(product)}
                  >
                    <ShoppingCart size={12} className="mr-1" />
                    Add
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <ProductDetail 
        product={selectedProduct} 
        isOpen={isDetailOpen} 
        onClose={() => setIsDetailOpen(false)} 
      />
    </div>
  );
};

export default ProductSuggestions;
