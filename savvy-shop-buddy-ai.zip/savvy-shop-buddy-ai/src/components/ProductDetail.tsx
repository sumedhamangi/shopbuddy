
import React, { useState } from "react";
import { Product, formatCurrency } from "@/lib/data";
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { 
  ShoppingCart, 
  Heart, 
  Share2, 
  Star, 
  ChevronLeft,
  Plus,
  Minus
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

interface ProductDetailProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, isOpen, onClose }) => {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast.success(`Added ${quantity} ${product.name} to your cart`);
  };

  const handleIncrement = () => {
    if (quantity < product.stock) {
      setQuantity(prev => prev + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={open => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden max-h-[90vh]">
        <DialogHeader className="px-6 pt-6 pb-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-4 top-4" 
            onClick={onClose}
          >
            <ChevronLeft size={18} />
          </Button>
          <DialogTitle className="text-xl sm:text-2xl text-shop-primary">
            {product.name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="overflow-y-auto px-6">
          <div className="relative w-full h-72 sm:h-80 mb-6">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover object-center rounded-lg" 
            />
          </div>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Star size={20} className="text-shop-accent fill-shop-accent" />
              <Star size={20} className="text-shop-accent fill-shop-accent" />
              <Star size={20} className="text-shop-accent fill-shop-accent" />
              <Star size={20} className="text-shop-accent fill-shop-accent" />
              <Star size={20} className={`${product.rating >= 4.5 ? "text-shop-accent fill-shop-accent" : "text-gray-300"}`} />
              <span className="ml-2 text-gray-700">({product.rating})</span>
            </div>
            <div className="text-2xl font-bold text-shop-primary">
              {formatCurrency(product.price)}
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {product.tags.map((tag, index) => (
              <Badge key={index} variant="outline" className="bg-gray-100 hover:bg-gray-200">
                {tag}
              </Badge>
            ))}
          </div>
          
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
            <p className="text-gray-700">{product.description}</p>
          </div>
          
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center border border-gray-300 rounded-md">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-10 w-10 rounded-r-none" 
                onClick={handleDecrement}
                disabled={quantity <= 1}
              >
                <Minus size={16} />
              </Button>
              <div className="h-10 px-3 flex items-center justify-center border-x border-gray-300 min-w-[40px]">
                {quantity}
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-10 w-10 rounded-l-none" 
                onClick={handleIncrement}
                disabled={quantity >= product.stock}
              >
                <Plus size={16} />
              </Button>
            </div>
            
            <div className="text-sm text-gray-500">
              {product.stock > 0 ? `${product.stock} available` : "Out of stock"}
            </div>
          </div>
        </div>
        
        <DialogFooter className="px-6 pb-6 pt-2 gap-2 sm:gap-0">
          <div className="grid grid-cols-2 gap-2 w-full">
            <Button variant="outline" onClick={() => toast.success(`Added ${product.name} to favorites`)}>
              <Heart size={18} className="mr-2" />
              Favorite
            </Button>
            <Button variant="outline" onClick={() => toast.success(`Sharing ${product.name}`)}>
              <Share2 size={18} className="mr-2" />
              Share
            </Button>
          </div>
          <Button 
            onClick={handleAddToCart} 
            className="w-full bg-shop-primary hover:bg-shop-primary/90"
            disabled={product.stock <= 0}
          >
            <ShoppingCart size={18} className="mr-2" />
            Add to Cart
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ProductDetail;
