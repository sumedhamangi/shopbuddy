"use client";

import React, { useState, useRef, useEffect } from "react";
import { Message, Product, mockProducts, formatCurrency } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Send, 
  Mic, 
  MicOff,
  Bot,
  X,
  Volume2,
  VolumeX,
  Waves,
  MessageSquare
} from "lucide-react";
import ProductSuggestions from "./ProductSuggestions";
import { useIsMobile } from "@/hooks/use-mobile";
import { toast } from "sonner";
import { useGemini } from '@/hooks/useGemini';
import { cn } from "@/lib/utils";
import ReactMarkdown from 'react-markdown';
import { useCart } from "@/contexts/CartContext";

interface ChatMessage {
  id: string;
  text: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface MessageHistory {
  content: string;
  role: string;
}

interface ChatInterfaceProps {
  onToggleCart: () => void;
  cartItemsCount: number;
  isOpen: boolean;
  onClose: () => void;
  onToggleChat: () => void;
}

// Add type definitions for SpeechRecognition
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
  error: string;
}

interface SpeechRecognitionResultList {
  length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  isFinal: boolean;
  length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onerror: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
}

declare global {
  interface Window {
    SpeechRecognition: {
      new (): SpeechRecognition;
    };
    webkitSpeechRecognition: {
      new (): SpeechRecognition;
    };
  }
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  onToggleCart, 
  cartItemsCount,
  isOpen,
  onClose,
  onToggleChat
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([{
    id: "welcome",
    text: "Hi there! I'm your shopping assistant. How can I help you today?",
    role: "assistant",
    timestamp: new Date()
  }]);

  const [input, setInput] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [suggestions, setSuggestions] = useState<Product[]>([]);
  const [viewedProducts, setViewedProducts] = useState<string[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const gemini = useGemini();
  const { items, totalPrice, totalItems, addToCart } = useCart();
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [isAISpeaking, setIsAISpeaking] = useState(false);
  const [voiceLevel, setVoiceLevel] = useState(0);
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null);
  const animationFrameRef = useRef<number>();
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);

  // Get available voices
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);

  useEffect(() => {
    // Load available voices
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);
      
      // Try to find a natural-sounding voice
      const preferredVoice = availableVoices.find(voice => 
        voice.name.includes('Google') || 
        voice.name.includes('Natural') ||
        voice.name.includes('Female')
      ) || availableVoices[0];
      
      setSelectedVoice(preferredVoice);
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  // Initialize audio context for voice visualization
  useEffect(() => {
    if (isVoiceMode) {
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
    }

    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, [isVoiceMode]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const speakAIResponse = (text: string) => {
    if (!isVoiceMode || !selectedVoice) return;

    // Cancel any ongoing speech
    if (speechSynthesisRef.current) {
      window.speechSynthesis.cancel();
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = selectedVoice;
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Add natural pauses
    utterance.text = text.replace(/\./g, '. ').replace(/,/g, ', ');

    utterance.onstart = () => {
      setIsAISpeaking(true);
      startVoiceVisualization();
    };

    utterance.onend = () => {
      setIsAISpeaking(false);
      stopVoiceVisualization();
    };

    utterance.onerror = () => {
      setIsAISpeaking(false);
      stopVoiceVisualization();
    };

    speechSynthesisRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  const startVoiceVisualization = () => {
    if (!analyserRef.current) return;

    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const updateVisualization = () => {
      analyserRef.current?.getByteFrequencyData(dataArray);
      const average = dataArray.reduce((a, b) => a + b) / bufferLength;
      setVoiceLevel(average / 128); // Normalize to 0-1 range
      animationFrameRef.current = requestAnimationFrame(updateVisualization);
    };

    updateVisualization();
  };

  const stopVoiceVisualization = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    setVoiceLevel(0);
  };

  const toggleVoiceMode = () => {
    setIsVoiceMode(prev => !prev);
    if (!isVoiceMode) {
      window.speechSynthesis.cancel();
      setIsAISpeaking(false);
      stopVoiceVisualization();
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || !gemini) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: input,
      role: "user",
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    
    // Create message history for context
    const messageHistory: MessageHistory[] = [...messages, userMessage].map(msg => ({
      content: msg.text,
      role: msg.role
    }));
    
    // Show typing indicator
    setIsTyping(true);
    
    try {
      // Check if user wants to checkout
      if (input.toLowerCase().includes('checkout') || input.toLowerCase().includes('complete purchase')) {
        const checkoutResponse = await gemini.handleCheckout({
          cartItems: items,
          totalPrice,
          totalItems
        });
        
        const aiResponse: ChatMessage = {
          id: (Date.now() + 1).toString(),
          text: checkoutResponse,
          role: "assistant",
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, aiResponse]);
        setSuggestions([]);
        speakAIResponse(checkoutResponse);
        return;
      }

      // Check if user wants to add items to cart
      const addToCartMatch = input.match(/add (\d+) (.+) to cart/i) || 
                           input.match(/add (.+) to cart/i) ||
                           input.match(/put (\d+) (.+) in cart/i) ||
                           input.match(/put (.+) in cart/i) ||
                           input.match(/i want (\d+) (.+)/i) ||
                           input.match(/i want (.+)/i) ||
                           input.match(/get (\d+) (.+)/i) ||
                           input.match(/get (.+)/i) ||
                           input.match(/buy (\d+) (.+)/i) ||
                           input.match(/buy (.+)/i) ||
                           input.match(/give me (\d+) (.+)/i) ||
                           input.match(/give me (.+)/i);

      if (addToCartMatch) {
        const quantity = parseInt(addToCartMatch[1]) || 1;
        const productName = addToCartMatch[2] || addToCartMatch[1];
        
        // Find the product in mockProducts with better matching
        const product = mockProducts.find(p => {
          const productNameLower = p.name.toLowerCase();
          const searchNameLower = productName.toLowerCase();
          
          // Exact match
          if (productNameLower === searchNameLower) return true;
          
          // Contains match
          if (productNameLower.includes(searchNameLower)) return true;
          
          // Word match (handles partial matches)
          const productWords = productNameLower.split(/\s+/);
          const searchWords = searchNameLower.split(/\s+/);
          return searchWords.every(word => 
            productWords.some(pWord => pWord.includes(word))
          );
        });

        if (product) {
          try {
            // Check stock before adding
            if (product.stock < quantity) {
              const stockMessage: ChatMessage = {
                id: (Date.now() + 1).toString(),
                text: `I'm sorry, but we only have ${product.stock} ${product.name}(s) in stock. Would you like to add ${product.stock} instead?`,
                role: "assistant",
                timestamp: new Date()
              };
              setMessages(prev => [...prev, stockMessage]);
              speakAIResponse(stockMessage.text);
              return;
            }

            // Check if this is a confirmation response
            const isConfirmation = input.toLowerCase().includes('yes') || 
                                 input.toLowerCase().includes('okay') ||
                                 input.toLowerCase().includes('sure') ||
                                 input.toLowerCase().includes('proceed');

            if (isConfirmation) {
              // Add the product to cart
              addToCart(product, quantity);
              
              // Get AI response for adding to cart
              const cartResponse = await gemini.addToCart(product.id, quantity);
              
              const aiResponse: ChatMessage = {
                id: (Date.now() + 1).toString(),
                text: cartResponse.message,
                role: "assistant",
                timestamp: new Date()
              };
              
              setMessages(prev => [...prev, aiResponse]);
              speakAIResponse(cartResponse.message);
              
              // Show related products after adding to cart
              const relatedProducts = await gemini.generateProductSuggestions(
                `Show me products related to ${product.name}`,
                {
                  previousMessages: messageHistory,
                  viewedProducts,
                  allProducts: mockProducts
                }
              );
              
              const products: Product[] = relatedProducts.recommendations.map(rec => ({
                id: rec.id,
                name: rec.name,
                price: parseFloat(rec.price),
                image: rec.image,
                description: rec.description,
                category: rec.category,
                tags: rec.tags,
                rating: rec.rating,
                stock: rec.stock
              }));
              
              setSuggestions(products);
              return;
            } else {
              // Ask for confirmation
              const confirmationMessage: ChatMessage = {
                id: (Date.now() + 1).toString(),
                text: `I can add ${quantity} ${product.name}(s) to your cart. The total will be ${formatCurrency(product.price * quantity)}. Would you like to proceed?`,
                role: "assistant",
                timestamp: new Date()
              };
              setMessages(prev => [...prev, confirmationMessage]);
              speakAIResponse(confirmationMessage.text);
              return;
            }
          } catch (error) {
            console.error('Error adding to cart:', error);
            const errorMessage: ChatMessage = {
              id: (Date.now() + 1).toString(),
              text: "I apologize, but I'm having trouble adding the item to your cart. Please try again or let me know if you'd like to try a different product.",
              role: "assistant",
              timestamp: new Date()
            };
            setMessages(prev => [...prev, errorMessage]);
            speakAIResponse(errorMessage.text);
          }
        } else {
          // Try to find similar products
          const similarProducts = mockProducts.filter(p => {
            const productNameLower = p.name.toLowerCase();
            const searchNameLower = productName.toLowerCase();
            return productNameLower.includes(searchNameLower) || 
                   searchNameLower.includes(productNameLower);
          });

          if (similarProducts.length > 0) {
            const similarProductsMessage = similarProducts
              .slice(0, 3)
              .map(p => `- ${p.name}`)
              .join('\n');

            const notFoundMessage: ChatMessage = {
              id: (Date.now() + 1).toString(),
              text: `I couldn't find a product matching "${productName}". Here are some similar products you might be interested in:\n${similarProductsMessage}\n\nWould you like to add any of these to your cart instead?`,
              role: "assistant",
              timestamp: new Date()
            };
            setMessages(prev => [...prev, notFoundMessage]);
            speakAIResponse(notFoundMessage.text);
          } else {
            const notFoundMessage: ChatMessage = {
              id: (Date.now() + 1).toString(),
              text: `I couldn't find a product matching "${productName}". Could you please try a different name or describe the product you're looking for?`,
              role: "assistant",
              timestamp: new Date()
            };
            setMessages(prev => [...prev, notFoundMessage]);
            speakAIResponse(notFoundMessage.text);
          }
        }
      }
      
      // Get AI response
      const aiResponseText = await gemini.generateResponse(userMessage.text, {
        previousMessages: messageHistory,
        viewedProducts,
        cartItems: items
      });
      
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: aiResponseText,
        role: "assistant",
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiResponse]);
      speakAIResponse(aiResponseText);
      
      // Always try to show recommendations unless explicitly not needed
      const shouldShowSuggestions = !input.toLowerCase().includes('checkout') && 
                                  !input.toLowerCase().includes('complete purchase') &&
                                  !input.toLowerCase().includes('no recommendations') &&
                                  !input.toLowerCase().includes('stop suggesting');
      
      if (shouldShowSuggestions) {
        // Get smart product suggestions
        const smartSuggestions = await gemini.generateProductSuggestions(
          userMessage.text,
          {
            previousMessages: messageHistory,
            viewedProducts,
            allProducts: mockProducts
          }
        );
        
        // Convert recommendations to Product type
        const products: Product[] = smartSuggestions.recommendations.map(rec => ({
          id: rec.id,
          name: rec.name,
          price: parseFloat(rec.price),
          image: rec.image,
          description: rec.description,
          category: rec.category,
          tags: rec.tags,
          rating: rec.rating,
          stock: rec.stock
        }));
        
        setSuggestions(products);
        
        if (products.length > 0) {
          setViewedProducts(prev => [
            ...prev, 
            ...products.map(p => p.id).filter(id => !prev.includes(id))
          ]);
        }
      } else {
        setSuggestions([]);
      }
    } catch (error) {
      console.error('Error processing message:', error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: "I apologize, but I'm having trouble processing your request. Please try again.",
        role: "assistant",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      setSuggestions([]);
      speakAIResponse(errorMessage.text);
    } finally {
      setIsTyping(false);
    }
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;

        recognitionRef.current.onresult = (event) => {
          const transcript = Array.from(event.results)
            .map(result => result[0])
            .map(result => result.transcript)
            .join('');
          setInput(transcript);
        };

        recognitionRef.current.onerror = (event) => {
          console.error('Speech recognition error', event.error);
          toast.error('Speech recognition error');
          setIsListening(false);
        };
      } else {
        toast.error('Speech recognition not supported in this browser');
        return;
      }
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      toast.info('Voice input deactivated');
    } else {
      recognitionRef.current.start();
      setIsListening(true);
      toast.info('Voice input activated');
    }
  };

  const handleProductSelected = (productId: string) => {
    // Add to viewed products
    if (!viewedProducts.includes(productId)) {
      setViewedProducts(prev => [...prev, productId]);
    }
  };

  const renderMarkdown = (text: string) => (
    <div className="prose prose-sm max-w-none">
      <ReactMarkdown>{text}</ReactMarkdown>
    </div>
  );

  const clearChatHistory = () => {
    setMessages([{
      id: "welcome",
      text: "Hi there! I'm your shopping assistant. How can I help you today?",
      role: "assistant",
      timestamp: new Date()
    }]);
  };

  return (
    <>
      {/* Chat panel */}
      <div
        className={`fixed bottom-0 right-0 z-[9999] bg-white shadow-2xl border-t md:border-l border-gray-200 w-full md:w-[500px] h-[60vh] md:h-[70vh] transition-all duration-300 ease-in-out ${
          isOpen ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Chat header */}
          <div className="p-4 border-b bg-gradient-to-r from-shop-primary to-shop-primary/90 text-white sticky top-0 z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bot size={28} className="text-white" />
                <h2 className="text-xl font-semibold">AI Shopping Assistant</h2>
              </div>
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={clearChatHistory}
                  className="text-white hover:bg-white/20 transition-all duration-300"
                  title="Clear chat history"
                >
                  <X size={24} />
                </Button>
                <div className="relative">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={toggleVoiceMode}
                    className={`text-white hover:bg-white/20 transition-all duration-300 ${
                      isVoiceMode ? 'bg-white/20 scale-110' : ''
                    }`}
                  >
                    {isVoiceMode ? <Volume2 size={24} /> : <VolumeX size={24} />}
                  </Button>
                  {isAISpeaking && (
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2">
                      <div className="flex items-center gap-1">
                        {[...Array(3)].map((_, i) => (
                          <div
                            key={i}
                            className="w-1 h-4 bg-white rounded-full animate-pulse"
                            style={{
                              animationDelay: `${i * 0.1}s`,
                              transform: `scaleY(${1 + voiceLevel})`
                            }}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <button 
                  onClick={onClose}
                  className="p-2 rounded-full hover:bg-white/20 transition-colors duration-200"
                >
                  <X size={24} />
                </button>
              </div>
            </div>
          </div>

          {/* Messages container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={cn(
                  "flex",
                  message.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                <div
                  className={cn(
                    "max-w-[85%] rounded-lg p-4 transition-all duration-200",
                    message.role === "user"
                      ? "bg-shop-primary text-white rounded-tr-none"
                      : "bg-white text-gray-800 rounded-tl-none border"
                  )}
                >
                  {renderMarkdown(message.text)}
                  <span className="text-xs opacity-70 mt-1 block">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex items-center space-x-2 animate-fade-in">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
              </div>
            )}
            
            {isListening && (
              <div className="mr-auto mb-4 bg-white border border-gray-200 rounded-lg p-3 flex items-center gap-2 animate-fade-in">
                <Mic size={20} className="text-shop-primary animate-pulse" />
                <span className="text-sm">Listening...</span>
              </div>
            )}
            
            {suggestions.length > 0 && (
              <div className="mr-auto mb-4 bg-white border border-gray-200 rounded-lg p-3 max-w-[90%] animate-fade-in">
                <ProductSuggestions 
                  products={suggestions} 
                  onProductSelect={handleProductSelected}
                />
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input area */}
          <div className="bg-white border-t border-gray-200 p-4 sticky bottom-0">
            <div className="flex items-center gap-3">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={toggleListening} 
                className={`shrink-0 transition-all duration-300 ${
                  isListening ? "bg-shop-primary text-white hover:bg-shop-primary/90 scale-110" : ""
                }`}
              >
                {isListening ? <MicOff size={24} /> : <Mic size={24} />}
              </Button>
              
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask me about products..."
                onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                className="flex-1 border-gray-300 focus:border-shop-primary focus-visible:ring-shop-primary transition-colors duration-200"
              />
              
              <Button 
                variant="default" 
                size="icon" 
                onClick={handleSendMessage}
                disabled={!input.trim()}
                className="bg-shop-primary hover:bg-shop-primary/90 shrink-0 transition-all duration-300 hover:scale-110"
              >
                <Send size={24} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChatInterface;
