
import React from "react";
import { Product, formatCurrency } from "@/lib/data";
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { Star, ShoppingCart, Heart } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

interface ProductCardProps {
  product: Product;
  onSelect?: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering onSelect
    addToCart(product, 1);
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering onSelect
    toast.success(`Added ${product.name} to favorites`);
  };

  return (
    <div 
      className="product-card cursor-pointer" 
      onClick={() => onSelect && onSelect(product)}
    >
      <div className="relative">
        <img 
          src={product.image} 
          alt={product.name} 
          className="product-card-image" 
        />
        <div className="absolute top-2 right-2">
          <button 
            onClick={handleFavorite}
            className="p-1.5 bg-white rounded-full shadow hover:bg-gray-100"
          >
            <Heart size={18} className="text-shop-primary" />
          </button>
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-medium text-gray-900 mb-1">{product.name}</h3>
            <div className="flex items-center mb-2">
              <Star size={16} className="text-shop-accent fill-shop-accent" />
              <span className="text-sm text-gray-700 ml-1">{product.rating}</span>
              <span className="mx-2 text-gray-300">|</span>
              <span className="text-sm text-gray-500">
                {product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}
              </span>
            </div>
          </div>
          <div className="text-lg font-bold text-shop-primary">
            {formatCurrency(product.price)}
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mt-2 mb-3">
          {product.tags.map((tag, index) => (
            <Badge key={index} variant="outline" className="bg-gray-100 hover:bg-gray-200">
              {tag}
            </Badge>
          ))}
        </div>
        
        <Button 
          onClick={handleAddToCart} 
          variant="default" 
          className="w-full bg-shop-primary hover:bg-shop-primary/90"
        >
          <ShoppingCart size={16} className="mr-2" />
          Add to Cart
        </Button>
      </div>
    </div>
  );
};

export default ProductCard;
