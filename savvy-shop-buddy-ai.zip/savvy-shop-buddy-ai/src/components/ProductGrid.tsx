
import React, { useState } from "react";
import { Product } from "@/lib/data";
import ProductCard from "./ProductCard";
import ProductDetail from "./ProductDetail";

interface ProductGridProps {
  products: Product[];
}

const ProductGrid: React.FC<ProductGridProps> = ({ products }) => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsDetailOpen(true);
  };

  const handleCloseDetail = () => {
    setIsDetailOpen(false);
  };

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard 
            key={product.id} 
            product={product} 
            onSelect={handleSelectProduct} 
          />
        ))}
      </div>
      
      <ProductDetail 
        product={selectedProduct} 
        isOpen={isDetailOpen} 
        onClose={handleCloseDetail} 
      />
    </>
  );
};

export default ProductGrid;
