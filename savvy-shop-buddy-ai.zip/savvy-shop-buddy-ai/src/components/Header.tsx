import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  ShoppingCart as CartIcon, 
  Menu,
  User,
  Heart,
  X,
  Bot
} from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { categories } from "@/lib/data";
import { Link } from "react-router-dom";
import { toast } from "sonner";

interface HeaderProps {
  cartItemsCount: number;
  onToggleCart: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  onToggleChat: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  cartItemsCount, 
  onToggleCart, 
  searchQuery, 
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  onToggleChat
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className={`sticky top-0 z-50 bg-white shadow-sm transition-shadow ${isScrolled ? 'shadow' : ''}`}>
      <div className="container mx-auto px-4">
        {/* Main header row */}
        <div className="h-16 md:h-20 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="font-bold text-2xl text-shop-primary flex items-center space-x-2">
            <ShoppingCartLogo />
            <span>ShopBuddy</span>
          </Link>
          
          {/* Search - hidden on mobile */}
          <div className="hidden md:flex-1 md:flex md:max-w-lg mx-8">
            <div className="relative w-full flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder="Search products..."
                  className="pl-10 pr-4 py-2 border-gray-300 focus:border-shop-primary focus:ring-shop-primary"
                />
              </div>
              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 bg-gradient-to-r from-shop-primary to-shop-primary/90 text-white hover:from-shop-primary/90 hover:to-shop-primary transition-all duration-300 transform hover:scale-110 relative group"
                onClick={onToggleChat}
              >
                <Bot size={20} />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center animate-pulse">
                  AI
                </span>
              </Button>
            </div>
          </div>
          
          {/* Right side actions */}
          <div className="flex items-center space-x-1 md:space-x-3">
            <Button 
              variant="ghost" 
              size="icon" 
              className="hidden md:flex"
              onClick={() => toast.info("Favorites feature coming soon!")}
            >
              <Heart size={20} />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="hidden md:flex">
                  <User size={20} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => toast.info("Sign in feature coming soon!")}>
                  Sign In
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => toast.info("Create account feature coming soon!")}>
                  Create Account
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onToggleCart} 
              className="relative"
            >
              <CartIcon size={20} />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-shop-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Button>
            
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden"
              onClick={toggleMobileMenu}
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </Button>
          </div>
        </div>
        
        {/* Mobile search - only visible on mobile */}
        <div className="md:hidden pb-3">
          <div className="relative w-full flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <Input
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search products..."
                className="pl-10 pr-4 py-1.5 border-gray-300 focus:border-shop-primary focus:ring-shop-primary"
              />
            </div>
            <Button
              variant="outline"
              size="icon"
              className="h-10 w-10 bg-gradient-to-r from-shop-primary to-shop-primary/90 text-white hover:from-shop-primary/90 hover:to-shop-primary transition-all duration-300 transform hover:scale-110 relative group"
              onClick={onToggleChat}
            >
              <Bot size={20} />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center animate-pulse">
                AI
              </span>
            </Button>
          </div>
        </div>
        
        {/* Navigation */}
        <nav className={`md:flex md:py-3 overflow-hidden transition-all duration-300 ease-in-out ${isMobileMenuOpen ? 'max-h-60' : 'max-h-0 md:max-h-none'}`}>
          <ul className="flex flex-col md:flex-row md:space-x-4 overflow-x-auto whitespace-nowrap pb-3 md:pb-0">
            {categories.map((category) => (
              <li key={category}>
                <button 
                  onClick={() => onCategoryChange(category)}
                  className={`text-sm py-2 px-3 rounded-md transition-colors md:py-1 block md:inline-block w-full text-left
                    ${selectedCategory === category 
                      ? 'bg-shop-primary text-white' 
                      : 'text-gray-700 hover:bg-gray-100'
                    }`}
                >
                  {category}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

const ShoppingCartLogo = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 2L3 6V20C3 20.5304 3.21071 21.0391 3.58579 21.4142C3.96086 21.7893 4.46957 22 5 22H19C19.5304 22 20.0391 21.7893 20.4142 21.4142C20.7893 21.0391 21 20.5304 21 20V6L18 2H6Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M3 6H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M16 10C16 11.0609 15.5786 12.0783 14.8284 12.8284C14.0783 13.5786 13.0609 14 12 14C10.9391 14 9.92172 13.5786 9.17157 12.8284C8.42143 12.0783 8 11.0609 8 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export default Header;
