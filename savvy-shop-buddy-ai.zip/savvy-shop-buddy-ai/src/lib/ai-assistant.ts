import { Product, mockProducts, formatCurrency } from "./data";

// Types of AI assistant responses
export type ResponseType = 
  | "greeting" 
  | "product_suggestion" 
  | "product_details"
  | "price_inquiry"
  | "availability"
  | "checkout_help"
  | "purchase_confirmation"
  | "general_inquiry";

// Fallback suggestion logic
export const generateFallbackSuggestions = (
  input: string,
  previousMessages: Array<{content: string, role: string}>,
  viewedProducts: string[] = []
): Product[] => {
  const chatHistory = previousMessages.map(msg => msg.content.toLowerCase()).join(' ');
  
  let matchedProducts = mockProducts.filter(product => {
    const searchIn = [
      product.name.toLowerCase(),
      product.description.toLowerCase(),
      product.category.toLowerCase(),
      ...product.tags.map(tag => tag.toLowerCase())
    ].join(' ');
    
    return input.toLowerCase().split(' ').some(word => 
      word.length > 3 && searchIn.includes(word)
    );
  });
  
  if (matchedProducts.length === 0) {
    const possibleCategories = [...new Set(mockProducts.map(p => p.category.toLowerCase()))];
    const categoryMatches = possibleCategories.filter(cat => chatHistory.includes(cat.toLowerCase()));
    
    if (categoryMatches.length > 0) {
      matchedProducts = mockProducts.filter(p => 
        categoryMatches.includes(p.category.toLowerCase())
      );
    }
  }
  
  if (matchedProducts.length === 0 || matchedProducts.length > 10) {
    matchedProducts = mockProducts.sort((a, b) => b.rating - a.rating);
  }
  
  const filteredProducts = matchedProducts.filter(p => !viewedProducts.includes(p.id));
  const sortedProducts = filteredProducts.sort((a, b) => b.rating - a.rating);
  
  return sortedProducts.slice(0, 3);
};

// Helper functions
export const getGeneralResponse = (input: string): string => {
  const responses = [
    "I'm here to help with your shopping needs. Could you tell me more about what you're looking for?",
    "I'd be happy to assist you. Are you looking for anything specific today?",
    "I can help you find the perfect products. What type of items are you interested in?",
    "Let me know what you're shopping for, and I'll help you find the best options."
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
};
