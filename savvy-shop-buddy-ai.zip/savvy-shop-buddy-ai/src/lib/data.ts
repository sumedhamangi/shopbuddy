
export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  category: string;
  tags: string[];
  rating: number;
  stock: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export const mockProducts: Product[] = [
  {
    id: "p1",
    name: "Wireless Noise-Cancelling Headphones",
    price: 249.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "Premium wireless headphones with advanced noise cancellation technology, providing an immersive audio experience.",
    category: "Electronics",
    tags: ["Headphones", "Wireless", "Noise-Cancelling"],
    rating: 4.5,
    stock: 25
  },
  {
    id: "p2",
    name: "Smart Fitness Watch",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "Advanced fitness tracker with heart rate monitoring, GPS, and personalized workout guidance.",
    category: "Wearables",
    tags: ["Fitness", "Smartwatch", "Health"],
    rating: 4.3,
    stock: 42
  },
  {
    id: "p3",
    name: "Ultralight Laptop",
    price: 1299.99,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "Powerful yet lightweight laptop with a stunning display and all-day battery life.",
    category: "Electronics",
    tags: ["Laptop", "Ultrabook", "Productivity"],
    rating: 4.8,
    stock: 15
  },
  {
    id: "p4",
    name: "Professional Camera",
    price: 899.99,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "High-resolution digital camera with interchangeable lenses for professional photography.",
    category: "Photography",
    tags: ["Camera", "DSLR", "Professional"],
    rating: 4.6,
    stock: 18
  },
  {
    id: "p5",
    name: "Smart Home Speaker",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1589003077984-894e133dabab?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "Voice-controlled smart speaker with premium sound quality and intelligent assistant.",
    category: "Smart Home",
    tags: ["Speaker", "Smart Home", "Voice Assistant"],
    rating: 4.2,
    stock: 30
  },
  {
    id: "p6",
    name: "Premium Coffee Maker",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "Programmable coffee maker with built-in grinder for the perfect brew every morning.",
    category: "Home & Kitchen",
    tags: ["Coffee", "Kitchen", "Appliance"],
    rating: 4.7,
    stock: 20
  },
  {
    id: "p7",
    name: "Leather Messenger Bag",
    price: 149.99,
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "Genuine leather messenger bag with multiple compartments, perfect for work or travel.",
    category: "Fashion",
    tags: ["Bag", "Leather", "Accessories"],
    rating: 4.4,
    stock: 22
  },
  {
    id: "p8",
    name: "Wireless Earbuds",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1605464315542-bda3e2f4e605?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
    description: "True wireless earbuds with premium sound quality and long battery life.",
    category: "Electronics",
    tags: ["Earbuds", "Wireless", "Audio"],
    rating: 4.1,
    stock: 35
  },
];

export const categories = [
  "All Categories",
  ...Array.from(new Set(mockProducts.map(product => product.category)))
];

export const getProductsByCategory = (category: string): Product[] => {
  if (category === "All Categories") return mockProducts;
  return mockProducts.filter(product => product.category === category);
};

export const getProductById = (id: string): Product | undefined => {
  return mockProducts.find(product => product.id === id);
};

export const getProductsByQuery = (query: string): Product[] => {
  const lowercaseQuery = query.toLowerCase();
  return mockProducts.filter(product => 
    product.name.toLowerCase().includes(lowercaseQuery) || 
    product.description.toLowerCase().includes(lowercaseQuery) || 
    product.category.toLowerCase().includes(lowercaseQuery) || 
    product.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery))
  );
};

export interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
}

export const generateProductSuggestions = (query: string): Product[] => {
  // In a real app, this would use an AI model to recommend products
  return getProductsByQuery(query).slice(0, 3);
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};
