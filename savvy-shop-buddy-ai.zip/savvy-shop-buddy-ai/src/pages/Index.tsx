import React, { useState } from "react";
import Header from "@/components/Header";
import ProductGrid from "@/components/ProductGrid";
import ChatInterface from "@/components/ChatInterface";
import ShoppingCart from "@/components/ShoppingCart";
import { useCart } from "@/contexts/CartContext";
import { getProductsByCategory, getProductsByQuery } from "@/lib/data";
import { toast } from "sonner";

const Index = () => {
  const { totalItems } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  
  // Filter products based on search query and category
  const filteredProducts = searchQuery
    ? getProductsByQuery(searchQuery)
    : getProductsByCategory(selectedCategory);

  const handleToggleCart = () => {
    setIsCartOpen(!isCartOpen);
  };

  const handleToggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
    // Reset category when searching
    if (query) {
      setSelectedCategory("All Categories");
    }
  };

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    // Clear search query when changing category
    if (searchQuery) {
      setSearchQuery("");
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header 
        cartItemsCount={totalItems}
        onToggleCart={handleToggleCart}
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
        selectedCategory={selectedCategory}
        onCategoryChange={handleCategoryChange}
        onToggleChat={handleToggleChat}
      />
      
      <main className="container mx-auto flex-1 px-4 py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-shop-primary mb-2">
            {searchQuery 
              ? `Search results for "${searchQuery}"` 
              : selectedCategory === "All Categories" 
                ? "All Products"
                : selectedCategory
            }
          </h1>
          <p className="text-gray-600">
            {filteredProducts.length} {filteredProducts.length === 1 ? 'product' : 'products'} available
          </p>
        </div>
        
        {filteredProducts.length > 0 ? (
          <ProductGrid products={filteredProducts} />
        ) : (
          <div className="text-center py-20">
            <h2 className="text-xl font-medium mb-2">No products found</h2>
            <p className="text-gray-600 mb-4">
              Try adjusting your search or category filters to find what you're looking for.
            </p>
            <button 
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("All Categories");
                toast.info("Showing all products");
              }}
              className="text-shop-primary hover:underline"
            >
              View all products
            </button>
          </div>
        )}
      </main>
      
      <ChatInterface 
        onToggleCart={handleToggleCart} 
        cartItemsCount={totalItems}
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
      />
      
      <ShoppingCart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </div>
  );
};

export default Index;
