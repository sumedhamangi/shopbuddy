import { useState, useEffect } from 'react';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { formatCurrency, mockProducts, Product } from '@/lib/data';

interface MessageHistory {
  content: string;
  role: string;
}

// System prompt for the shopping assistant
const SYSTEM_PROMPT = `You are an expert shopping assistant for an e-commerce store. Your role is to provide a complete, guided shopping experience:

1. Initial Greeting & Understanding:
   - Welcome customers warmly
   - Quickly understand their needs through brief questions
   - Identify their preferences and budget
   - ALWAYS show relevant product recommendations based on their initial needs

2. Product Discovery:
   - Suggest relevant products based on their needs
   - Explain key features and benefits
   - Compare similar products
   - Highlight best deals and promotions
   - ALWAYS include product recommendations in your responses
   - If a product is mentioned, show similar or related products

3. Purchase Guidance:
   - Help with product selection
   - Explain pricing and payment options
   - Guide through the checkout process
   - Handle any purchase-related questions
   - ALWAYS suggest complementary products or alternatives

4. Checkout Assistance:
   - When asked to checkout, guide the user through the process
   - Confirm cart contents and quantities
   - Help with payment method selection
   - Assist with shipping address and delivery options
   - Confirm order details before finalizing
   - Provide order confirmation and tracking information
   - Suggest related products for future purchases

5. Post-Purchase Support:
   - Provide order tracking information
   - Explain return policies
   - Offer related product suggestions
   - Address any concerns
   - ALWAYS suggest complementary products

Important Guidelines:
1. ALWAYS show product recommendations in your responses
2. If a product is mentioned, show similar or related products
3. When discussing features, suggest products that have those features
4. When comparing products, show all relevant options
5. After checkout, suggest complementary products
6. Keep responses concise but always include product suggestions
7. Never say "I don't know" - always provide alternatives
8. Guide users step by step through their shopping journey
9. Focus on completing purchases
10. Maintain a friendly, professional tone
11. Always suggest specific products
12. Help with any shopping-related questions

Remember: Your goal is to help users find and purchase products they need while providing an excellent shopping experience. ALWAYS include relevant product recommendations in your responses.`;

interface GeminiResponse {
  success: boolean;
  message: string;
}

interface ProductRecommendation {
  id: string;
  name: string;
  price: string;
  image: string;
  description: string;
  category: string;
  tags: string[];
  rating: number;
  stock: number;
}

interface ProductSuggestions {
  recommendations: ProductRecommendation[];
}

interface CartItem {
  product: Product;
  quantity: number;
}

interface CheckoutResponse {
  success: boolean;
  message: string;
  orderId?: string;
}

export const useGemini = () => {
  const [gemini, setGemini] = useState<{
    generateResponse: (message: string, context: {
      previousMessages: MessageHistory[];
      viewedProducts: string[];
      cartItems: CartItem[];
    }) => Promise<string>;
    generateProductSuggestions: (query: string, context: {
      previousMessages: MessageHistory[];
      viewedProducts: string[];
      allProducts: Product[];
    }) => Promise<ProductSuggestions>;
    handleCheckout: (cart: {
      cartItems: CartItem[];
      totalPrice: number;
      totalItems: number;
    }) => Promise<string>;
    shouldShowRecommendations: (userInput: string, aiResponse: string, context: {
      previousMessages: MessageHistory[];
      viewedProducts: string[];
      cartItems: CartItem[];
    }) => Promise<boolean>;
    addToCart: (productId: string, quantity: number) => Promise<GeminiResponse>;
  } | null>(null);

  useEffect(() => {
    // Only initialize on client side
    if (typeof window !== 'undefined') {
      // Use Vite's import.meta.env instead of process.env
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
      if (!apiKey) {
        console.error('Gemini API key is not set. Please add VITE_GEMINI_API_KEY to your environment variables.');
        return;
      }

      const genAI = new GoogleGenerativeAI(apiKey);
      // Using the latest Gemini 2.0 Flash model
      const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-001" });

      const generateResponse = async (
        input: string,
        context: {
          previousMessages: Array<{ content: string; role: string }>;
          viewedProducts: string[];
          cartItems: any[];
        }
      ): Promise<string> => {
        try {
          const prompt = `You are a shopping assistant for an online store. Your task is to help customers find products and complete their purchases.

Available Products: ${JSON.stringify(mockProducts)}

IMPORTANT RULES:
1. ONLY recommend products that exist in the available products list above
2. NEVER suggest products that are not in the inventory
3. If a product is not available, suggest similar products from the inventory
4. Always check product availability before recommending
5. Focus on helping users find what they need from the available products

User Input: ${input}
Previous Messages: ${JSON.stringify(context.previousMessages)}
Viewed Products: ${context.viewedProducts.join(', ')}
Cart Items: ${context.cartItems.length}

Provide a helpful response that:
1. Addresses the user's query
2. Only suggests products from the available inventory
3. Helps guide them to make a purchase decision
4. Maintains a friendly and professional tone`;

          const result = await model.generateContent({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.8,
              maxOutputTokens: 1024,
            }
          });
          
          return result.response.text();
        } catch (error) {
          console.error('Error generating response:', error);
          return "I apologize, but I'm having trouble processing your request. Please try again.";
        }
      };

      const generateProductSuggestions = async (
        userInput: string,
        context: {
          previousMessages: Array<{ content: string; role: string }>;
          viewedProducts: string[];
          allProducts: any[];
        }
      ): Promise<{
        recommendations: Array<{
          id: string;
          name: string;
          price: string;
          image: string;
          description: string;
          reason: string;
          category: string;
          tags: string[];
          rating: number;
          stock: number;
        }>;
        summary: string;
      }> => {
        try {
          const prompt = `You are a product recommendation system. Based on the following information, analyze the user's needs and return a structured JSON response with detailed product recommendations.

Available Products: ${JSON.stringify(context.allProducts)}

STRICT RULES:
1. ONLY recommend products that exist in the available products list above
2. NEVER suggest products outside the inventory
3. Each recommendation MUST match a product ID from the available products
4. Use EXACT product details from the inventory
5. If no suitable products exist, return an empty recommendations array

User Input: ${userInput}
Viewed Products: ${context.viewedProducts.join(', ')}
Previous Conversation: ${context.previousMessages.map(m => m.content).join('\n')}

Return a JSON object with the following structure:
{
  "recommendations": [
    {
      "id": "must_match_existing_product_id",
      "name": "exact_product_name_from_inventory",
      "price": "exact_price_from_inventory",
      "image": "exact_image_url_from_inventory",
      "description": "exact_description_from_inventory",
      "reason": "why_this_product_matches_user_needs",
      "category": "exact_category_from_inventory",
      "tags": ["exact_tags_from_inventory"],
      "rating": exact_rating_from_inventory,
      "stock": exact_stock_from_inventory
    }
  ],
  "summary": "brief_summary_of_recommendations"
}

Important Guidelines:
1. Verify each product ID exists in the inventory
2. Use exact product details, do not modify them
3. Only recommend products that are in stock
4. Consider user's previous interactions
5. Make recommendations actionable and clear`;

          const result = await model.generateContent({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.3,
              topK: 20,
              topP: 0.8,
              maxOutputTokens: 1024,
            }
          });
          
          const response = result.response.text();
          const cleanResponse = response.trim().replace(/^```json\n?|\n?```$/g, '');
          const parsedResponse = JSON.parse(cleanResponse);
          
          // Validate recommendations against mock products
          const validatedRecommendations = parsedResponse.recommendations
            .filter((rec: any) => {
              const matchingProduct = context.allProducts.find((p: any) => p.id === rec.id);
              return matchingProduct && matchingProduct.stock > 0;
            })
            .map((rec: any) => {
              const matchingProduct = context.allProducts.find((p: any) => p.id === rec.id);
              return {
                ...matchingProduct,
                reason: rec.reason
              };
            });
          
          return {
            ...parsedResponse,
            recommendations: validatedRecommendations
          };
        } catch (error) {
          console.error('Product Suggestion Error:', error);
          return {
            recommendations: [],
            summary: "Let me help you find the perfect products. What are you looking for today?"
          };
        }
      };

      const handleCheckout = async (
        context: {
          cartItems: Array<{
            product: {
              id: string;
              name: string;
              price: number;
            };
            quantity: number;
          }>;
          totalPrice: number;
          totalItems: number;
        }
      ): Promise<string> => {
        try {
          const cartSummary = context.cartItems.map(item => 
            `${item.quantity}x ${item.product.name} - ${formatCurrency(item.product.price * item.quantity)}`
          ).join('\n');

          const prompt = `You are processing a checkout request. Here are the cart details:

Cart Contents:
${cartSummary}

Total Items: ${context.totalItems}
Total Price: ${formatCurrency(context.totalPrice)}

Please provide a clear, step-by-step checkout process message that:
1. Confirms the cart contents
2. Asks for shipping details
3. Explains payment options
4. Provides clear next steps
5. Ensures order accuracy

Keep the response concise and focused on completing the purchase.`;

          const result = await model.generateContent({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.3,
              topK: 20,
              topP: 0.8,
              maxOutputTokens: 1024,
            }
          });

          return result.response.text();
        } catch (error) {
          console.error('Checkout Error:', error);
          return "I'll help you complete your purchase. Let's review your cart and proceed with checkout.";
        }
      };

      const shouldShowRecommendations = async (
        userInput: string,
        aiResponse: string,
        context: {
          previousMessages: Array<{ content: string; role: string }>;
          viewedProducts: string[];
          cartItems: any[];
        }
      ): Promise<boolean> => {
        try {
          const prompt = `You are a shopping assistant. Analyze the following conversation and determine if product recommendations would be helpful.

Available Products: ${JSON.stringify(mockProducts)}

STRICT RULES:
1. Only show recommendations if relevant products exist in the inventory
2. Consider if the user is looking for specific products
3. Check if recommendations would help the user make a decision
4. Verify the conversation is focused on product discovery
5. Ensure recommendations would be from available products

User Input: ${userInput}
AI Response: ${aiResponse}
Previous Messages: ${JSON.stringify(context.previousMessages)}
Viewed Products: ${context.viewedProducts.join(', ')}
Cart Items: ${context.cartItems.length}

Return a JSON object with a single property "showRecommendations" that is either true or false.
Only return true if:
1. The user is looking for products
2. Relevant products exist in the inventory
3. Recommendations would be helpful
4. The conversation is about shopping`;

          const result = await model.generateContent({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.1,
              topK: 1,
              topP: 0.1,
              maxOutputTokens: 50,
            }
          });
          
          const response = result.response.text();
          const cleanResponse = response.trim().replace(/^```json\n?|\n?```$/g, '');
          const parsedResponse = JSON.parse(cleanResponse);
          return parsedResponse.showRecommendations;
        } catch (error) {
          console.error('Error determining recommendations:', error);
          return false;
        }
      };

      const addToCart = async (
        productId: string,
        quantity: number
      ): Promise<{ success: boolean; message: string }> => {
        try {
          const product = mockProducts.find(p => p.id === productId);
          if (!product) {
            return {
              success: false,
              message: "I apologize, but I couldn't find that product in our inventory."
            };
          }

          if (product.stock < quantity) {
            return {
              success: false,
              message: `I'm sorry, but we only have ${product.stock} ${product.name}(s) in stock.`
            };
          }

          const prompt = `You are a shopping assistant. A user wants to add a product to their cart.

Product Details:
- Name: ${product.name}
- Price: ${formatCurrency(product.price)}
- Quantity: ${quantity}
- Stock: ${product.stock}

Generate a friendly confirmation message that:
1. Confirms the product was added to cart
2. Mentions the quantity and total price
3. Suggests next steps (e.g., continue shopping or checkout)
4. Maintains a helpful and professional tone

Return a JSON object with:
{
  "success": true,
  "message": "your confirmation message here"
}`;

          const result = await model.generateContent({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.3,
              topK: 20,
              topP: 0.8,
              maxOutputTokens: 256,
            }
          });

          const response = result.response.text();
          const cleanResponse = response.trim().replace(/^```json\n?|\n?```$/g, '');
          const parsedResponse = JSON.parse(cleanResponse);

          return {
            success: true,
            message: parsedResponse.message
          };
        } catch (error) {
          console.error('Error adding to cart:', error);
          return {
            success: false,
            message: "I apologize, but I'm having trouble adding that item to your cart. Please try again."
          };
        }
      };

      setGemini({
        generateResponse,
        generateProductSuggestions,
        handleCheckout,
        shouldShowRecommendations,
        addToCart
      });
    }
  }, []);

  return gemini;
}; 